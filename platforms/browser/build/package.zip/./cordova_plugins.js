cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [];
module.exports.metadata = 
// TOP OF METADATA
{
    "com.piqnt.fastcontext": "0.1.3"
}
// BOTTOM OF METADATA
});